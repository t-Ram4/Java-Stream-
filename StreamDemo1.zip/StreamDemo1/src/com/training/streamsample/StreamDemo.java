package com.training.streamsample;

import java.util.Arrays;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String[] args) {
		
		Integer[] myNums = {1,2,3};
		
		//stream the array
		Stream<Integer> myStream = Arrays.stream(myNums);
		
		long numberOfElements = myStream.count();
		
		//long values = myStream.count();
		
		System.out.println("Number of elements in the stream: "+numberOfElements);
		//System.out.println("Number of elements in the stream: "+values);

	}

}
