package com.training.streamsample;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamFromCollectionDemo {

	public static void main(String[] args) {
		
		List<Double> tempInChennaiList = new ArrayList<Double>();
		
		tempInChennaiList.add(98.8);
		tempInChennaiList.add(102.2);
		tempInChennaiList.add(101.1);
		tempInChennaiList.add(103.2);
		tempInChennaiList.add(99.2);
		
		
		Stream<Double> tempStream = tempInChennaiList.stream();
		
		long tempInChennai = tempStream.filter((i)->i>100.0).count();
		
		System.out.println("Temperatures greater than 100 degree: "+tempInChennai );

	}

}
