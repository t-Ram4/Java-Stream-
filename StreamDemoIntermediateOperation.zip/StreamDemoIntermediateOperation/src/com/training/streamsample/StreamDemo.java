package com.training.streamsample;

import java.util.Arrays;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String[] args) {
		
		Integer[] myNums = {1,2,3};
		
		//stream the array
		Stream<Integer> myStream = Arrays.stream(myNums);
		
		//filter the elements which are greater than 2. the argument of filter is a predicate.
		long numberOfElements = myStream.filter((i)->i>2).count();
		
		System.out.println("Number of elements in the stream: "+numberOfElements);

	}

}
