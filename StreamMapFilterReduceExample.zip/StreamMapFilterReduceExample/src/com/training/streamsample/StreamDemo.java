package com.training.streamsample;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String[] args) {
		
		List<Integer> nums = new ArrayList<Integer>();
		
		nums.add(1);
		nums.add(2);
		nums.add(3);
		nums.add(4);
		nums.add(5);
		nums.add(6);
		
		Stream<Integer> numsStream = nums.stream();
		long result = numsStream.map((n)->(n*n)).filter((i)->i>20).count();
		
		System.out.println("The values greater than 20: "+result);
		

	}

}
