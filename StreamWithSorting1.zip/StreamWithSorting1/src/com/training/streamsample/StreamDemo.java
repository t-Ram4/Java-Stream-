package com.training.streamsample;

import java.util.List;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String[] args) {
	
		Stream<String> sortedStream = Stream.of("Kumar","Santhosh","Ravi","Anish","Mohan","Yuvan").sorted();
		
		//forEach method uses consumer as argument. Consumer accepts input but does not return anything.
		sortedStream.forEach((e)->System.out.println(e));

	}

}
